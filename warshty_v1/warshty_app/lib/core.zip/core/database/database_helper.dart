import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../constants/app_constants.dart';

/// مساعد قاعدة البيانات — Singleton
/// يدير إنشاء وتحديث قاعدة بيانات SQLite
class DatabaseHelper {
  // ── Singleton ──────────────────────────────────────────────
  static DatabaseHelper? _instance;
  static Database? _database;

  DatabaseHelper._internal();
  static DatabaseHelper get instance {
    _instance ??= DatabaseHelper._internal();
    return _instance!;
  }

  // ── Database Access ────────────────────────────────────────

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, AppConstants.dbName);
    return await openDatabase(
      path,
      version: AppConstants.dbVersion,
      onCreate: _onCreate,
      onOpen: _onOpen,
    );
  }

  Future<void> _onOpen(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  // ── Schema Creation ────────────────────────────────────────

  Future<void> _onCreate(Database db, int version) async {
    // 1. جدول الأشخاص
    await db.execute('''
      CREATE TABLE persons (
        id TEXT PRIMARY KEY NOT NULL,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        category TEXT DEFAULT 'عميل',
        notes TEXT DEFAULT '',
        dateAdded TEXT NOT NULL,
        status TEXT DEFAULT 'active'
      )
    ''');

    // 2. جدول التصنيفات
    await db.execute('''
      CREATE TABLE categories (
        id TEXT PRIMARY KEY NOT NULL,
        name TEXT NOT NULL,
        type TEXT NOT NULL
      )
    ''');

    // 3. جدول الشغلانات
    await db.execute('''
      CREATE TABLE jobs (
        id TEXT PRIMARY KEY NOT NULL,
        name TEXT NOT NULL,
        customerId TEXT NOT NULL,
        workshop TEXT NOT NULL,
        productType TEXT DEFAULT '',
        agreedAmount REAL NOT NULL,
        notes TEXT DEFAULT '',
        status TEXT DEFAULT 'in_progress',
        startDate TEXT,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        FOREIGN KEY (customerId) REFERENCES persons(id) ON DELETE CASCADE
      )
    ''');

    // 4. جدول الخامات (كيان ضعيف — جزء من الشغلانة)
    await db.execute('''
      CREATE TABLE job_materials (
        id TEXT NOT NULL,
        jobId TEXT NOT NULL,
        description TEXT NOT NULL,
        quantity REAL NOT NULL,
        unitCost REAL NOT NULL,
        totalCost REAL NOT NULL,
        PRIMARY KEY (id, jobId),
        FOREIGN KEY (jobId) REFERENCES jobs(id) ON DELETE CASCADE
      )
    ''');

    // 5. جدول المصنعيات (كيان ضعيف)
    await db.execute('''
      CREATE TABLE job_labor_items (
        id TEXT NOT NULL,
        jobId TEXT NOT NULL,
        description TEXT NOT NULL,
        cost REAL NOT NULL,
        PRIMARY KEY (id, jobId),
        FOREIGN KEY (jobId) REFERENCES jobs(id) ON DELETE CASCADE
      )
    ''');

    // 6. جدول التكاليف الأخرى (كيان ضعيف)
    await db.execute('''
      CREATE TABLE job_other_costs (
        id TEXT NOT NULL,
        jobId TEXT NOT NULL,
        description TEXT NOT NULL,
        cost REAL NOT NULL,
        PRIMARY KEY (id, jobId),
        FOREIGN KEY (jobId) REFERENCES jobs(id) ON DELETE CASCADE
      )
    ''');

    // 7. جدول دفعات الشغلانة (كيان ضعيف)
    await db.execute('''
      CREATE TABLE job_payments (
        id TEXT NOT NULL,
        jobId TEXT NOT NULL,
        date TEXT NOT NULL,
        amount REAL NOT NULL,
        PRIMARY KEY (id, jobId),
        FOREIGN KEY (jobId) REFERENCES jobs(id) ON DELETE CASCADE
      )
    ''');

    // 8. جدول المعاملات المالية للأشخاص (كيان ضعيف)
    await db.execute('''
      CREATE TABLE person_transactions (
        id TEXT NOT NULL,
        personId TEXT NOT NULL,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        date TEXT,
        description TEXT DEFAULT '',
        PRIMARY KEY (id, personId),
        FOREIGN KEY (personId) REFERENCES persons(id) ON DELETE CASCADE
      )
    ''');

    // 9. جدول واردات الخزنة
    await db.execute('''
      CREATE TABLE treasury_income (
        id TEXT PRIMARY KEY NOT NULL,
        date TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT NOT NULL,
        category TEXT DEFAULT '',
        workshop TEXT DEFAULT 'عام',
        linkedJobId TEXT
      )
    ''');

    // 10. جدول مصروفات الخزنة
    await db.execute('''
      CREATE TABLE treasury_expenses (
        id TEXT PRIMARY KEY NOT NULL,
        date TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT NOT NULL,
        category TEXT DEFAULT '',
        workshop TEXT DEFAULT 'عام',
        linkedJobId TEXT
      )
    ''');

    // 11. جدول دفتر الأستاذ
    await db.execute('''
      CREATE TABLE ledger_transactions (
        id TEXT PRIMARY KEY NOT NULL,
        date TEXT NOT NULL,
        amount REAL NOT NULL,
        type TEXT NOT NULL,
        personId TEXT,
        jobId TEXT,
        category TEXT,
        description TEXT,
        source TEXT NOT NULL
      )
    ''');

    // 12. جدول إعدادات التطبيق
    await db.execute('''
      CREATE TABLE settings (
        key TEXT PRIMARY KEY NOT NULL,
        value TEXT
      )
    ''');

    // ── Seed data — التصنيفات الافتراضية ──────────────────
    await _seedCategories(db);
  }

  Future<void> _seedCategories(Database db) async {
    final categories = [
      {'id': 'c1', 'name': 'كهرباء', 'type': 'expense'},
      {'id': 'c2', 'name': 'ميات', 'type': 'expense'},
      {'id': 'c3', 'name': 'إيجار', 'type': 'expense'},
      {'id': 'c4', 'name': 'رواتب', 'type': 'expense'},
      {'id': 'c5', 'name': 'نقل', 'type': 'expense'},
      {'id': 'c6', 'name': 'صيانة', 'type': 'expense'},
      {'id': 'c7', 'name': 'خامات', 'type': 'expense'},
      {'id': 'c8', 'name': 'دفعة عميل', 'type': 'income'},
      {'id': 'c9', 'name': 'عربون', 'type': 'income'},
      {'id': 'c10', 'name': 'إيراد منوع', 'type': 'income'},
      {'id': 'c11', 'name': 'أجرة نجار', 'type': 'labor'},
      {'id': 'c12', 'name': 'أجرة دهان', 'type': 'labor'},
      {'id': 'c13', 'name': 'أجرة تركيب', 'type': 'labor'},
      {'id': 'c14', 'name': 'أجرة عام', 'type': 'labor'},
    ];

    for (final cat in categories) {
      await db.insert('categories', cat);
    }
  }

  // ── Helper: توليد ID فريد ──────────────────────────────────

  /// توليد ID جديد باستخدام الوقت + عشوائي
  /// يطابق دالة uid() في الـ JavaScript
  static String nextPartialId() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final random = (now.toRadixString(36) +
            (DateTime.now().microsecondsSinceEpoch % 100000).toRadixString(36))
        .substring(0, 10);
    return random;
  }
}
